[![License MIT](https://img.shields.io/pypi/l/kstoolbox?color=blue)](https://raw.githubusercontent.com/Rian-T/kstoolbox/master/LICENSE.md)
![Python 3.6](https://img.shields.io/badge/python-3.6-green.svg)

# Toolbox for AI Hackathon

Contains method to quickly create a dataset from Google Images or Instagram to train a classifier.
